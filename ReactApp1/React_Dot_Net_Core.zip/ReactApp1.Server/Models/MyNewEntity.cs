﻿namespace ReactApp1.Server.Models
{
    public class MyNewEntity
    {
        public int Id { get; set; } // Primary key
        public string Name { get; set; }
        public DateTime CreatedAt { get; set; }
    }
}
